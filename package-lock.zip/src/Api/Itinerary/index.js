export const getAllItenerary = () =>{
    return axios.get(`${process.env.REACT_APP_BASE_URL}/event/get-all-itinerary`);
}