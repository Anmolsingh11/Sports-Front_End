export const sports =[
    {
        name:"Badminton",
        Icon:"badminton.png"
    },
    {
        name:"Squash",
        Icon:"squash.png"
    },
    {
        name:"Lawn Tennis",
        Icon:"tennis.png"
    },
    {
        name:"Table Tennis",
        Icon:"table-tennis.png"
    },
    {
        name:"Snooker",
        Icon:"snooker.png"
    },
    {
        name:"Volley Ball",
        Icon:"volleyball-net.png"
    },
    {
        name:"Kabaddi",
        Icon:""
    },
    {
        name:"Cricket",
        Icon:"cricket-player.png"
    },
    {
        name:"Kho Kho",
        Icon:""
    },
    {
        name:"Pithu",
        Icon:"medicine-ball.png"
    },
    {
        name:"Spoon Race",
        Icon:"spoon.png"
    },
    {
        name:"Tire Relay Race",
        Icon:""
    },
    {
        name:"Relay Race",
        Icon:"relay.png"
    },
    {
        name:"Sack Race",
        Icon:"sack-race.png"
    },
    {
        name:"Tug Of War",
        Icon:"tug-of-war.png"
    },
    {
        name:"Three Leg Race",
        Icon:""
    },
    {
        name:"Carrom",
        Icon:"carrom.png"
    },
    {
        name:"Musical Chair",
        Icon:"chair.png"
    },
    {
        name:"Beer Pong",
        Icon:"beer-pong.png"
    },
]

