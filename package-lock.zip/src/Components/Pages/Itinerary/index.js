import Navbar from "../../Navbar";
import Footer from "../../Footer";
const itinerary = () => {
    return (
        <>
            <Navbar />
            <div className="card mt-3 mx-3" style={{borderRadius:'15px',boxShadow:'0px 2px 4px 2px #eee'}}>
                <div className="card-body">
                    <p>
                        itinerary
                        <select style={{float:'right'}}>
                            <option>22nd jan</option>
                            <option>23rd jan</option>
                        </select>
                    </p>
                    <p>January 22nd 2023</p>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-4">
                                <p>09:00AM</p>
                            </div>
                            <div className="col-6">
                    <p>Event Name <br/> Venue</p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <p>09:00AM</p>
                            </div>
                            <div className="col-6">
                    <p>Event Name <br/> Venue</p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <p>09:00AM</p>
                            </div>
                            <div className="col-6">
                    <p>Event Name <br/> Venue</p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-4">
                                <p>09:00AM</p>
                            </div>
                            <div className="col-6">
                    <p>Event Name <br/> Venue</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    );
}

export default itinerary;