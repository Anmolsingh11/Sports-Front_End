const Navbar = () =>{
    return(
        <div className="card header" style={{borderRadius: "0px 0px 20px 20px"}}>
            <div className="card-body">
            </div>
        </div>
    );
}

export default Navbar;